package cn.ubia.util;
public interface ShowDialogCallback {
	void callback(boolean sure);
}