package cn.ubia.util;
public interface ShowItemSelectDialogCallback {
	void callback(int which);
}