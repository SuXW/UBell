package cn.ubia.bean;

public class ZigbeeInfo {

	public ZigbeeInfo() {
		// TODO Auto-generated constructor stub
	}

	public  String macaddr ;
	public  String info ;
}
