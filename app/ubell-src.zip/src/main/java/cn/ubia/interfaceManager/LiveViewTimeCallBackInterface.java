package cn.ubia.interfaceManager;

 
 
/**
 * @author dftx
 *
 */
public interface LiveViewTimeCallBackInterface {
 
 
	public void TimeUTCStatecallback(long UTCtime  );  
	public void saveTimeMsSeccallback(long saveTime);
	
}
