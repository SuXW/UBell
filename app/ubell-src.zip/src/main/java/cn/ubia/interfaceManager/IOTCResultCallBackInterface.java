package cn.ubia.interfaceManager;

 
 
/**
 * @author dftx
 *
 */
public interface IOTCResultCallBackInterface {
 
 
	void IOTCCMDStatecallback(int IOTCCMD,int result  );  
}
