package cn.ubia.interfaceManager;

 
 
/**
 * @author dftx
 *
 */
public interface DoorCallBackInterface {
 
 
	void DoorStatecallback(int DoorState  );  
}
