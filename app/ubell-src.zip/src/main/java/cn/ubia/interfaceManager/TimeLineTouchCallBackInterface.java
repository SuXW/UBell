package cn.ubia.interfaceManager;

 
 
/**
 * @author dftx
 *
 */
public interface TimeLineTouchCallBackInterface {
 
 
	void TimeLineTouchStatecallback(int mTouchstate);  
}
