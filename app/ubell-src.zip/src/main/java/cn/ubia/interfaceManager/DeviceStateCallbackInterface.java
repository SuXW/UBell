package cn.ubia.interfaceManager;

 
 
public interface DeviceStateCallbackInterface {
 
 
	void DeviceStateCallbackInterface(String did, int type, int param) ; 
	void DeviceStateCallbackLiveInterface(String did, int type, int param) ; 
}
