package cn.ubia.interfaceManager;

import cn.ubia.bean.ZigbeeInfo;

 
 
/**
 * @author dftx
 *
 */
public interface ZigbeeInfoCallBackInterface {
 
 
	void ZigbeeInfocallback(ZigbeeInfo mZigbeeInfo  );  
}
