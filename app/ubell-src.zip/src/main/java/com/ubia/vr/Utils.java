package com.ubia.vr;

import android.util.Log;

public class Utils {
	static String TAG = "DONG_YUV";

	public static void LOGD(String msg) {
		Log.e(TAG, msg);
	}
	
	public static void LOGE(String msg) {
		Log.e(TAG, msg);
	}

}
