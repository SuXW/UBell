package com.ubia.vr;

public interface ISimplePlayer {

    public void onPlayStart();

    public void onReceiveState(int state);
}
