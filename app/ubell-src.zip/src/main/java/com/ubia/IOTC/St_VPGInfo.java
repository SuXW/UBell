package com.ubia.IOTC;


/******************************************************************************
 *                                                                            *
 * Copyright (c) 2011 by TUTK Co.LTD. All Rights Reserved.                    *
 *                                                                            *
 *                                                                            *
 * Class: St_SInfo.java                                                       *
 *                                                                            *
 * Author: joshua ju                                                          *
 *                                                                            *
 * Date: 2011-05-14                                                           *
 *                                                                            *
 ******************************************************************************/

public class St_VPGInfo {
public int Vid;
public int Pid;
public int Gid;
public int Rsv;
}
