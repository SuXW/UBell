package com.ubia.IOTC;

/**
 * @author 作者  : WISE
 * @version 创建时间：2018/1/17  下午7:57
 * @description 类描述：
 * @project 项目： Doorbell-1.0.27-180117
 * @天天都是星期一
 */


public class HARDWAEW_INFO {
    public   int  width = 0;
    public   int  height = 0;
    public   int  angle = 180;
    public   int  type = 0;
    public   int resolution = 720;
    public   float maxFinger = 210f;  //
    public   float  minFinger = 150.0f;
}
