package com.mp4;

public class H264SliceType {
    public static final int H264_TYPE_P     = 0;
    public static final int H264_TYPE_B     = 1;
    public static final int H264_TYPE_I     = 2;
    public static final int H264_TYPE_SP    = 3;
    public static final int H264_TYPE_SI    = 4;
    public static final int H264_TYPE2_P    = 5;
    public static final int H264_TYPE2_B    = 6;
    public static final int H264_TYPE2_I    = 7;
    public static final int H264_TYPE2_SP   = 8;
    public static final int H264_TYPE2_SI   = 9;
}
