package com.tutk.IOTC;


public class st_LanSearchInfo {

   public byte[] IP = null;
   public byte[] UID = null;
   public int port = 0;
}
