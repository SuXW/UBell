package com.tutk.IOTC;


public class st_LanSearchInfo2 {

   public byte[] IP = null;
   public byte[] UID = null;
   public int port = 0;
   public byte[] DeviceName = null;
}
