package com.timeline.listenview;

 
 
public interface RollBackToCurrentTimeCallbackInterface {
 
 
	void RollBackToCurrentTimecallback(int  mTimeUTC  ); 
	 
}
