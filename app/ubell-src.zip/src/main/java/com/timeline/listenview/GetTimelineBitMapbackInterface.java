package com.timeline.listenview;

 
 
public interface GetTimelineBitMapbackInterface {
 
 
	void GetPushNoteStatecallback(NoteInfoData mNoteInfoData, boolean state); 
	
	void SetPushNoteStatecallback( boolean state); 
}
