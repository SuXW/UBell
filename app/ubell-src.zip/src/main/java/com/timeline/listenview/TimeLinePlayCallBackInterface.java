package com.timeline.listenview;

 
 
/**
 * @author dftx
 *
 */
public interface TimeLinePlayCallBackInterface {
 
 
	void TimeLinePlayStatecallback(int playBackTimeUTC );  
}
